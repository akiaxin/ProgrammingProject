class Background:
    #pygame import
    import pygame
    
    # Start Screen Variables
    width, height = 650, 650

    # Seal and background for the start screen
    setScreen = pygame.display.set_mode((width, height))

    loadOcean = pygame.image.load("AHwave.png")
    loadNoForkForest = pygame.image.load("SKNoForkForest.png")
    loadForkForest = pygame.image.load("SKForkForest.png")
    loadShop = pygame.image.load("SKShop.png")
    loadShore = pygame.image.load("SKShore.png")
    loadCity = pygame.image.load("SKCity.png")
    loadMan = pygame.image.load("SKMan.png")
    loadFrozen = pygame.image.load("SKFrozen.png")
    loadPath = pygame.image.load("SKPath.png")
    loadCabinOut = pygame.image.load("SKCabinOut.png")
    loadCabinIn = pygame.image.load("SKCabinIn.png")
    loadManGood = pygame.image.load("SKManGood.png")
    loadVictory = pygame.image.load("SKVictory.png")
    w,h = width, height
    xpos = width/2 - w/2
    ypos = height/2 - h/2

    oceanSize = pygame.transform.scale(loadOcean, (w, h))
    noForkForestSize = pygame.transform.scale(loadNoForkForest, (w, h))
    forkForestSize = pygame.transform.scale(loadForkForest, (w, h))
    shopSize = pygame.transform.scale(loadShop, (w, h))
    shoreSize = pygame.transform.scale(loadShore, (w, h))
    citySize = pygame.transform.scale(loadCity, (w, h))
    manSize = pygame.transform.scale(loadMan, (w, h))
    frozenSize = pygame.transform.scale(loadFrozen, (w, h))
    pathSize = pygame.transform.scale(loadPath, (w, h))
    cabinOutSize = pygame.transform.scale(loadCabinOut, (w, h))
    cabinInSize = pygame.transform.scale(loadCabinIn, (w, h))
    manGoodSize = pygame.transform.scale(loadManGood, (w, h))
    victorySize = pygame.transform.scale(loadVictory, (w, h))

    # screen.blit(sealSize, (xpos, ypos))

    # pygame.display.set_caption("Seal Game")

    # pygame.display.update()