class Weapon:
  