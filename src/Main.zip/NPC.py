class NPC:
  