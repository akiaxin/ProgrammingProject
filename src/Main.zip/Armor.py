class Armor:
  