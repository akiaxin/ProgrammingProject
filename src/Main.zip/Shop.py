class Shop:
  