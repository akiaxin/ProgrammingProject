class Consumable:
  