class Shop:
  # Variables
   goodNum = []

  # Constructor
  def __init__(self, damageMult, ammo, name):
    self.damageMult = damageMult
    self.ammo = ammo
    self.name = name