class Armor:
  # Variables
  prot = 0
  name = "tempName"
  
  def __init__(self, health, prot, name):
    self.prot = prot
    self.name = name