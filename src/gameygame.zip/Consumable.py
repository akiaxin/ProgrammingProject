class Consumable:
  # Variables
  name = "tempName"
  effectType = "tempType"
  effect = 0
  cost = 0
  desc = "tempDesc" # description